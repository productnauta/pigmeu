<?php

return "string";